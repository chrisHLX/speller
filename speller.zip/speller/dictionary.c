// Implements a dictionary's functionality

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>

#include "dictionary.h"

// Custom prototypes & variables
void loadD(const char *dictionary);
void initTable();
void insert(unsigned int hash, char *str);
struct node *createNode(char *str);
void printTable();

// Unload prototypes
void unloadN(struct node *n);
void unloadAll(struct node *tableA[]);

// File pointer used for the dictionary
FILE *dic = NULL;
unsigned int dicTotalWords = 0;
// END Custom


// Represents a node in a hash table
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;
}
node;

// Number of buckets in hash table
const unsigned int N = 3256;

// Hash table
node *table[N];

// Returns true if word is in dictionary else false
bool check(const char *word)
{
    unsigned int search = hash(word);
    if (table[search]->next == NULL)
    {
        return false;
    }
    else
    {
        node *trav = table[search]->next;
        while (trav != NULL)
        {
            int x = strcasecmp(trav->word, word);
            if (x == 0)
            {
                return true;
                break;
            }
            else
            {
                trav = trav->next;
            }
        }
        return false;
    }
}

// Hashes word to a number
// Hash function complements of Dan Bernstein
unsigned int hash(const char *word)
{
    unsigned int hashF = 5381;
    int c;

    while ((c = *word++))
    {
        // If capital make lower by adding 32 changing the ascii val
        if (c < 97 && c > 64)
        {
            c = c + 32;
        }
        hashF = ((hashF << 5) + hashF) + c; /* hash * 33 + c */
    }

    return hashF % N;
    return 0;
}

// Loads dictionary into memory, returning true if successful else false
bool load(const char *dictionary)
{
    dic = fopen(dictionary, "r");
    initTable();
    // Use fscanf to find strings and add them to an array
    char str[45];// = malloc(sizeof(char) * 45);
    int c = 0;

    for (int i = 0; c != EOF; i++)
    {
        c = fgetc(dic);

        if (c != EOF)
        {
            ungetc(c, dic);
            fscanf(dic, "%s", str);
            unsigned int hashTmp = hash(str);
            insert(hashTmp, str);
            dicTotalWords++;
        }

    }
    fclose(dic);
    if (dictionary != NULL)
    {
        return true;
    }
    else
    {
        return false;
    }
}

// Returns number of words in dictionary if loaded else 0 if not yet loaded
unsigned int size(void)
{
    return dicTotalWords - 1;
}

// Unloads dictionary from memory, returning true if successful else false
bool unload(void)
{
    unloadAll(table);
    if (table[N - 1])
    {
        return true;
    }
    else
    {
        return false;
    }
}

void insert(unsigned int hash, char *str)
{
    node *n = createNode(str);
    if (table[hash]->next == NULL)
    {
        table[hash]->next = n;
    }
    else
    {
        n->next = table[hash]->next;
        table[hash]->next = n;
    }
}

struct node *createNode(char *str)
{
    node *n = malloc(sizeof(node));
    if (n == NULL)
    {
        fprintf(stderr, "could not allocate memory");
    }

    for (int i = 0; i < strlen(str) + 1; i++)
    {
        n->word[i] = str[i];
    }

    n->next = NULL;
    return n;
}

void initTable()
{
    for (int i = 0; i < N; i++)
    {
        table[i] = (node *)malloc(sizeof(node));
        table[i]->next = NULL;
    }
}

void printTable()
{
    for (int i = 0; i < N; i++)
    {
        for (node *trav = table[i]->next; trav != NULL; trav = trav->next)
        {
            printf("table[%i]: %s\n", i, trav->word);
        }
    }
}

// Recursive unload
void unloadN(struct node *n)
{

    if (n->next)
    {
        unloadN(n->next);
    }


    free(n);
}

// Recursive unload Hashtable
void unloadAll(struct node *tableA[])
{
    for (int i = 0; i < N; i++)
    {
        if (table[i])
        {
            unloadN(tableA[i]);
        }
    }
}