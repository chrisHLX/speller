bool check(const char *word)
{
    unsigned int search = hash(word);
    node * trav = table[search]->next;

    if (trav == NULL)
    {
        return false;
    }
    else
    {
        while (trav != NULL)
        {
            int x = strcasecmp(trav->word, word);
            if (x == 0)
            {
                return true;
                break;
            }
            else
            {
                trav = trav->next;
            }
        }
        return false;
    }
}